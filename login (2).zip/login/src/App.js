import './App.css';
import { Switch, Route,BrowserRouter as Router, } from 'react-router-dom'
import Login from './components/Login';
import TodoList from './components/Todo';

function App() {
  return (
    <div className="App">
      <Router>
      <Switch>
        <Route exact path='/' component={Login}/>
        <Route path='/todo' component={TodoList}/>
        <Route exact path='/login' component={Login}/>
      </Switch>
      </Router>
      
    </div>
  );
}

export default App;

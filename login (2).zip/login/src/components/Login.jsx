import axios from 'axios';
import React, { Component } from 'react';

class Login extends Component {
    state = {
        users:[],
        email:'',
        password:''
      }
    constructor(){
        super();
        this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    }
    componentDidMount(){
        axios.get(`${process.env.REACT_APP_API_URL}/users`)
        .then(res=>{
            const users=res.data;
            console.log("axios users",users);
            this.setState({users})

        })

    }
    handleChange(event) {
        let payLoad={};
        payLoad[event.target.name]=event.target.value
        this.setState(payLoad);
      }
    
      handleSubmit(event) {
          let index = this.state.users.findIndex(item=>{
              return item.email === this.state.email
          })
          if(index >= 0){
            this.userExists(index);
          }
          else {
              alert("email does not exist");
          }
          
        
        event.preventDefault();
      }
      userExists(index){
          let user=this.state.users[index];
          if(user.username === this.state.password){
            this.props.history.push('/todo')
          }
          else {
              alert('incorrect password');
          }

      }
    
    render() { 
        return ( 
            <div>
                <h1>Login Page</h1>
                <form onSubmit={this.handleSubmit}>
        <label>
          Email:
          <input type="text" name="email" value={this.state.email} onChange={this.handleChange} />
        </label>
        <label>
          Password:
          <input type="text" name="password" value={this.state.password} onChange={this.handleChange} />
        </label>
        <input type="submit" value="Submit" />
      </form>

            </div>
         );
    }
}
 
export default Login;
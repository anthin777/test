import axios from 'axios';
import React, { Component } from 'react'

class TodoList extends Component {
    state = { 
        todo:[],
        columns:['ID','TITLE','STATUS'],
        data:[]
     }
     
     componentDidMount(){
        axios.get(`${process.env.REACT_APP_API_URL}/todos`)
        .then(res=>{
            const todo=res.data.filter(item=>{
                return item.completed
            });
            this.setState({data:todo})
            this.setState({todo});
        })
     }
     removeTodo(index){
         let todoList=this.state.todo;
         let todo=todoList[index];
         const filterdData=todoList.filter(item=>{
             
             if(todo.id === item.id){
                 item.completed=false;
             }
             return item.completed
         });
         this.setState({todo:filterdData});
     }
    render() { 
        return ( 
            <div>
                <h1>Todo List</h1>
                <table>
                    <thead>
                    <tr>
      <th>ID</th>
    <th>TITLE</th>
    <th>STATUS</th>
    
  </tr>
                    </thead>
  
  <tbody>
  {
      this.state.todo.map((item,i)=>(
        <tr key={i}>
        <td>{item.id}</td>
        <td>{item.title}</td>
        <td>{item.completed ? <input type="button" value="Delete" onClick={()=>this.removeTodo(i)} />:''}</td>
      </tr>

      ))
  }
  </tbody>
  
 
  
</table>

            </div>
         );
    }
}
 
export default TodoList;